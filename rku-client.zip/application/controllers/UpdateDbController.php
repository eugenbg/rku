<?php

class UpdateDbController extends Zend_Controller_Action
{

    private $uploadPath;
    public function init()
    {
        /* Initialize action controller here */
    }

    public function indexAction()
    {
        if($this->_request->isPost()){
            $this->clearUploadFolder();
            $file = $this->unzipUploadedFile();
            $path = $this->uploadPath.$file[2];
            $model = new Model_UpdateDb();
            $row = $model->update($path);
            $this->view->result = "В базу данных загружено $row записей";
        } else {
            $form = new Form_UpdateDbForm();
            $this->view->form = $form;
        }
    }

    public function clearUploadFolder()
    {
        // $_FILES['file'][tmp_name] здесь лежит файл
        $this->uploadPath = APPLICATION_PATH . '/files/';
        // deleting previous uploads
        $files = glob($this->uploadPath); // get all file names
        foreach($files as $file){ // iterate files
          if(is_file($file))
            unlink($file); // delete file
        }
    }

    public function unzipUploadedFile()
    {
        $zip = new ZipArchive;
        $res = $zip->open($_FILES['file']['tmp_name']);

        if ($res === TRUE) {
            $zip->extractTo($this->uploadPath);
            $file = scandir($this->uploadPath);
            $zip->close();
        } else {
            $this->view->result = 'Невозможно распаковать файл';
        }
        return $file;
    }
}

